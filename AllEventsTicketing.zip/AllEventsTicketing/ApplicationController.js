

function ApplicationController() {
	
	// execute business rule
	this.execute = function(cmdName) {
		/* 
		if (frontController.acceptableCommands[cmdName] != null) {				
			var cmd = "get" + cmdName;
			alert(cmd);
			businessRules.[cmd]();
		}
		*/
	}
	
	
}